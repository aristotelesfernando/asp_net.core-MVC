﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Capitulo02.Models;

namespace Capitulo02.Data
{
   public static class IESDbInitializer
   {
      public static void Initialize(IESContext context)
      {
         context.Database.EnsureCreated();

         if (context.Departamentos.Any())
         {
            return;
         }

         var departamentos = new Departamento[]
         {
            new Departamento{ Nome = "Ciencia da Computação" },
            new Departamento{ Nome = "ciencia de Alimentos" }
         };

         foreach (Departamento d in departamentos)
         {
            context.Departamentos.Add(d);
         }

         if (context.Instituicoes.Any())
         {
            return;
         }

         var instituicoes = new Instituicao[]
         {
            new Instituicao { Nome = "UniParana", Endereco = "Parana" },
            new Instituicao { Nome = "UniSanta", Endereco = "Santa Catarina" },
            new Instituicao { Nome = "UniSao", Endereco = "Sao Paulo" },
            new Instituicao { Nome = "UniSulgrandense", Endereco = "Rio Grande do Sul" },
            new Instituicao { Nome = "UniCarioca", Endereco = "Rio de Janeiro" }
         };

         foreach (Instituicao i in instituicoes)
         {
            context.Instituicoes.Add(i);
         }

         context.SaveChanges();
      }
   }
}
