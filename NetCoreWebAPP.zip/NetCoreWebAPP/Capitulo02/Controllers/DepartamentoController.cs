﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Capitulo02.Data;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Capitulo02.Controllers
{
   public class DepartamentoController : Controller
   {
      private readonly IESContext _context; 

      public DepartamentoController(IESContext context)
      {
         this._context = context;
      }
      // GET: /<controller>/
      public async Task<IActionResult> Index()
      {
         return View(await _context.Departamentos.OrderBy(c => c.Nome).ToListAsync());
      }

      public IActionResult Create()
      {
         return View();
      }

      [HttpPost]
      [ValidateAntiForgeryToken]
      public async Task<IActionResult> Create([Bind("Nome")] Models.Departamento departamento)
      {
         try
         {
            if (ModelState.IsValid)
            {
               _context.Add(departamento);
               await _context.SaveChangesAsync();
               return RedirectToAction(nameof(Index));
            }
         }
         catch (DbUpdateException)
         {
            ModelState.AddModelError("", "Não foi possivel inserir os dados de departamento!");
         }
         return View(departamento);
      }

      public async Task<IActionResult> Edit(long? id)
      {
         if (id == null)
         {
            return NotFound();
         }

         var departamento = await _context.Departamentos.SingleOrDefaultAsync(m => m.DepartamentoID == id);
         if (departamento == null)
         {
            return NotFound();
         }

         return View(departamento);
      }

      [HttpPost]
      [ValidateAntiForgeryToken]
      public async Task<IActionResult> Edit(long? id, [Bind("DepartamentoID, Nome")] Models.Departamento departamento)
      {
         if (id != departamento.DepartamentoID)
         {
            return NotFound();
         }
         if (ModelState.IsValid)
         {
            try
            {
               _context.Update(departamento);
               await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
               if (!DepartamentoExists(departamento.DepartamentoID))
               {
                  return NotFound();
               } else
               {
                  throw;
               }
            }
            return RedirectToAction(nameof(Index));
         }
         return View(departamento);
      }

      private bool DepartamentoExists(long? id)
      {
         return _context.Departamentos.Any(e => e.DepartamentoID == id);
      }

      public async Task<IActionResult> Details(long? id)
      {
         if (id == null)
         {
            return NotFound();
         }

         var departamento = await _context.Departamentos.SingleOrDefaultAsync(m => m.DepartamentoID == id);
         if (departamento == null)
         {
            return NotFound();
         }

         return View(departamento);
      }

      public async Task<IActionResult> Delete(long? id)
      {
         if (id == null)
         {
            return NotFound();
         }

         var departamento = await _context.Departamentos.SingleOrDefaultAsync(m => m.DepartamentoID == id);
         if (departamento == null)
         {
            return NotFound();
         }

         return View(departamento);
      }

      [HttpPost, ActionName("Delete")]
      [ValidateAntiForgeryToken]
      public async Task<IActionResult> DeleteConfirmed(long? id)
      {
         var departamento = await _context.Departamentos.SingleOrDefaultAsync(m => m.DepartamentoID == id);
         _context.Departamentos.Remove(departamento);
         await _context.SaveChangesAsync();

         return RedirectToAction(nameof(Index));
      }
   }
}
