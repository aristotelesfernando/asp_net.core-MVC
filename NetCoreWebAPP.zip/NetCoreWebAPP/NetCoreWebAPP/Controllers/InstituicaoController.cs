﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Capitulo01.Controllers
{
   public class InstituicaoController : Controller
   {
      private static IList<Models.Instituicao> instituicoes = new List<Models.Instituicao>()
      {
         new Models.Instituicao()
         {
            InstituicaoID = 1,
            Nome = "UniParana",
            Endereco = "Parana"
         },
         new Models.Instituicao()
         {
            InstituicaoID = 2,
            Nome = "UniSanta",
            Endereco = "Santa Catarina"
         },
         new Models.Instituicao()
         {
            InstituicaoID = 3,
            Nome = "UniSao",
            Endereco = "Sao Paulo"
         },
         new Models.Instituicao()
         {
            InstituicaoID = 4,
            Nome = "UniSulgrandense",
            Endereco = "Rio Grande do Sul"
         },
         new Models.Instituicao()
         {
            InstituicaoID = 5,
            Nome = "UniCarioca",
            Endereco = "Rio de Janeiro"
         }
      };
      public IActionResult Index()
      {
         return View(instituicoes);
      }

      //GET: Create
      public ActionResult Create()
      {
         return View();
      }

      [HttpPost]
      [ValidateAntiForgeryToken]
      public ActionResult Create(Models.Instituicao instituicao)
      {
         instituicoes.Add(instituicao);
         instituicao.InstituicaoID = instituicoes.Select(i => i.InstituicaoID).Max() + 1;

         return RedirectToAction("Index");
      }

      public ActionResult Edit(long id)
      {
         return View(instituicoes.Where(i => i.InstituicaoID == id).First());
      }

      [HttpPost]
      [ValidateAntiForgeryToken]
      public ActionResult Edit(Models.Instituicao instituicao)
      {
         instituicoes.Remove(instituicoes.Where(i => i.InstituicaoID == instituicao.InstituicaoID).First());
         instituicoes.Add(instituicao);

         return RedirectToAction("Index");
      }

      public ActionResult Details(long id)
      {
         return View(instituicoes.Where(i => i.InstituicaoID == id).First());
      }

      public ActionResult Delete(long id)
      {
         return View(instituicoes.Where(i => i.InstituicaoID == id).First());
      }

      [HttpPost]
      [ValidateAntiForgeryToken]
      public ActionResult Delete(Models.Instituicao instituicao)
      {
         instituicoes.Remove(instituicoes.Where(i => i.InstituicaoID == instituicao.InstituicaoID).First());
         return RedirectToAction("Index");
      }

   }
}